from kivy.lang import Builder
from kivymd.app import MDApp
import math
import webbrowser
from kivy.uix.popup import Popup
from kivy.uix.label import Label
from kivymd.uix.menu import MDDropdownMenu
from kivymd.uix.button import MDRaisedButton

# Only import GPS if on Android
try:
    from plyer import gps
    gps_available = True
except ImportError:
    gps_available = False

KV = '''
BoxLayout:
    orientation: 'vertical'
    spacing: 10
    padding: 10

    MDLabel:
        id: location_label
        text: "Select Ambulance Location"
        halign: "center"
        theme_text_color: "Primary"

    MDRaisedButton:
        text: "Choose Ambulance Location"
        pos_hint: {"center_x": 0.5}
        on_release: app.open_location_menu()

    MDRaisedButton:
        text: "Navigate to Nearest Hospital"
        pos_hint: {"center_x": 0.5}
        on_release: app.find_nearest_hospital()
'''

# List of hospitals (Coimbatore)
hospitals = [
    {"name": "PSG Hospitals", "lat": 11.018795, "lon": 77.007190},
    {"name": "KG Hospital", "lat": 11.0175, "lon": 76.9824},
    {"name": "Ganga Hospital", "lat": 11.0193, "lon": 76.9902},
    {"name": "Kovai Medical Center and Hospital", "lat": 11.044313, "lon":77.041090 },
    {"name": "Sri Ramakrishna Hospital", "lat": 11.0111, "lon": 76.9614},
    {"name": "Coimbatore Kidney Centre", "lat": 11.0027, "lon": 76.9825},
    {"name": "Coimbatore Cancer Foundation", "lat": 11.0425, "lon": 77.0137},
    {"name": "Lotus Eye Hospital and Institute", "lat": 11.0176, "lon": 76.9992},
    {"name": "Royal Care Super Speciality Hospital", "lat": 11.0445, "lon": 77.0234},
    {"name": "VGM Hospital", "lat": 11.0293, "lon": 77.0158},
    {"name": "Ortho One Hospital", "lat": 11.0116, "lon": 76.9825},
]

# Simulated locations
ambulance_locations = {
    "Peelamedu": (11.024606, 77.002209),
    "Gandhipuram": (11.0171, 76.9725),
    "Hopes": (11.020169,77.018758),
    "Singanallur": (11.0023, 77.0431),
}

class MainApp(MDApp):
    def build(self):
        self.theme_cls.primary_palette = "Blue"
        self.root = Builder.load_string(KV)

        self.latitude = None
        self.longitude = None

        if gps_available:
            try:
                gps.configure(on_location=self.update_location, on_status=self.on_status)
                gps.start(minTime=1000, minDistance=1)
            except NotImplementedError:
                self.show_popup('GPS Error', 'GPS not implemented on your platform')

        return self.root

    def update_location(self, **kwargs):
        self.latitude = kwargs['lat']
        self.longitude = kwargs['lon']
        self.root.ids.location_label.text = f"Location: {self.latitude}, {self.longitude}"

    def on_status(self, stype, status):
        print("GPS Status:", stype, status)

    def open_location_menu(self):
        menu_items = [
            {
                "viewclass": "OneLineListItem",
                "text": loc,
                "on_release": lambda x=loc: self.set_ambulance_location(x),
            }
            for loc in ambulance_locations
        ]
        self.menu = MDDropdownMenu(
            caller=self.root,
            items=menu_items,
            width_mult=4,
        )
        self.menu.open()

    def set_ambulance_location(self, location_name):
        self.menu.dismiss()
        self.latitude, self.longitude = ambulance_locations[location_name]
        self.root.ids.location_label.text = f"Ambulance at: {location_name}"

    def find_nearest_hospital(self):
        if self.latitude is None or self.longitude is None:
            self.show_popup("Error", "Please select ambulance location first!")
            return

        nearest = None
        min_distance = float('inf')
        for hospital in hospitals:
            dist = self.haversine(self.latitude, self.longitude, hospital['lat'], hospital['lon'])
            if dist < min_distance:
                min_distance = dist
                nearest = hospital

        if nearest:
            hospital_lat = nearest['lat']
            hospital_lon = nearest['lon']
            hospital_name = nearest['name']

            maps_url = f"https://www.google.com/maps/dir/?api=1&origin={self.latitude},{self.longitude}&destination={hospital_lat},{hospital_lon}&travelmode=driving"
            webbrowser.open(maps_url)

            self.root.ids.location_label.text = f"Navigating to: {hospital_name} ({round(min_distance, 2)} km)"
        else:
            self.root.ids.location_label.text = "No hospitals found."

    def haversine(self, lat1, lon1, lat2, lon2):
        R = 6371
        d_lat = math.radians(lat2 - lat1)
        d_lon = math.radians(lon2 - lon1)
        a = math.sin(d_lat/2)**2 + math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) * math.sin(d_lon/2)**2
        c = 2 * math.atan2(math.sqrt(a), math.sqrt(1-a))
        return R * c

    def show_popup(self, title, message):
        popup = Popup(title=title,
                      content=Label(text=message),
                      size_hint=(None, None), size=(400, 400))
        popup.open()

if __name__ == "__main__":
    MainApp().run()
